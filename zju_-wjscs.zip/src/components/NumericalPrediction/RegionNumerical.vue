<template>

</template>

<script>
    export default {
        name: "RegionNumerical"
    }
</script>

<style scoped>

</style>
