<template>

</template>

<script>
    export default {
        name: "Observation"
    }
</script>

<style scoped>

</style>
